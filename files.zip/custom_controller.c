/**
 * @file custom_controller.c
 * @brief RDM controller-side send functions for RDM_PID_MFR_CURVE.
 *
 * Modelled on the Weisbrod esp_dmx controller pattern (device_control.c).
 *
 * rdm_send_request() signature (from rdm/controller/include/utils.h):
 *
 *   size_t rdm_send_request(dmx_port_t dmx_num,
 *                           const rdm_request_t *request,
 *                           const char *format,   // response PD decode format
 *                           void *pd,             // response PD output buffer
 *                           size_t size,          // output buffer size
 *                           rdm_ack_t *ack);
 *
 * rdm_request_t fields for GET: dest_uid, sub_device, cc, pid only.
 *   (.pd / .pdl / .format are zero-initialised — no outgoing PD.)
 * rdm_request_t fields for SET: all of the above plus .pd, .pdl, .format
 *   describing the outgoing parameter data.
 *
 * FORMAT STRINGS (from driver.c rdm_format_encode):
 *   "w"  = uint16_t  (2 bytes, big-endian on wire)
 *   "$"  = terminator — stops after the preceding fixed token
 *   "w$" = exactly one uint16_t, then stop
 *
 * DMX_CHECK is intentionally not used — it references TAG which is extern
 * to this compilation unit (same issue as custom.c). Plain early-return
 * guards are used instead.
 *
 * INCLUDE NOTE:
 * rdm_send_request and rdm_request_t are declared in
 * rdm/controller/include/utils.h. rdm_uid_is_broadcast is in rdm/include/uid.h.
 * Both should be reachable from the sketch folder via the Arduino build
 * system's recursive library include path.
 */

#include "custom_controller.h"

#include "rdm/controller/include/utils.h"  /* rdm_send_request, rdm_request_t */
#include "rdm/include/uid.h"               /* rdm_uid_is_broadcast            */

/* ---------------------------------------------------------------------------
 * rdm_send_get_supported_parameters()
 *
 * Response format: "w" (unterminated) — the decoder repeats the uint16_t
 * token until PDL is exhausted, filling the caller's pids[] array.
 * Standard minimum-required PIDs are excluded by the responder per E1.20.
 * ------------------------------------------------------------------------- */
size_t rdm_send_get_supported_parameters(dmx_port_t dmx_num,
                                          const rdm_uid_t *dest_uid,
                                          rdm_sub_device_t sub_device,
                                          uint16_t *pids,
                                          size_t size,
                                          rdm_ack_t *ack) {
  if (dmx_num >= DMX_NUM_MAX)           return 0;
  if (dest_uid == NULL)                 return 0;
  if (rdm_uid_is_broadcast(dest_uid))   return 0;
  if (sub_device >= RDM_SUB_DEVICE_MAX) return 0;
  if (pids == NULL)                     return 0;

  const rdm_request_t request = {
    .dest_uid   = dest_uid,
    .sub_device = sub_device,
    .cc         = RDM_CC_GET_COMMAND,
    .pid        = RDM_PID_SUPPORTED_PARAMETERS,
    /* no outgoing PD */
  };

  /* "w" unterminated — repeated for each uint16_t until PDL exhausted */
  return rdm_send_request(dmx_num, &request, "w", pids, size, ack);
}

/* ---------------------------------------------------------------------------
 * rdm_send_get_parameter_description()
 *
 * Request format:  "w$"            — outgoing PD is the queried PID (uint16)
 * Response format: "wbbbx00bbddda" — matches rdm_parameter_description_t
 *   w    = pid          (uint16)
 *   b    = pdl_size     (uint8)
 *   b    = data_type    (uint8, rdm_ds_t)
 *   b    = cc           (uint8, rdm_pid_cc_t)
 *   x00  = literal 0x00 (reserved byte, not stored)
 *   b    = unit         (uint8)
 *   b    = prefix       (uint8)
 *   d    = min_value    (uint32)
 *   d    = max_value    (uint32)
 *   d    = default_value(uint32)
 *   a    = description  (ASCII string, up to 32 bytes)
 *
 * Format string taken directly from rdm_info.c's definition for
 * RDM_PID_PARAMETER_DESCRIPTION.
 * ------------------------------------------------------------------------- */
size_t rdm_send_get_parameter_description(dmx_port_t dmx_num,
                                           const rdm_uid_t *dest_uid,
                                           rdm_sub_device_t sub_device,
                                           rdm_pid_t pid,
                                           rdm_parameter_description_t *param_desc,
                                           rdm_ack_t *ack) {
  if (dmx_num >= DMX_NUM_MAX)           return 0;
  if (dest_uid == NULL)                 return 0;
  if (rdm_uid_is_broadcast(dest_uid))   return 0;
  if (sub_device >= RDM_SUB_DEVICE_MAX) return 0;
  if (param_desc == NULL)               return 0;

  const rdm_request_t request = {
    .dest_uid   = dest_uid,
    .sub_device = sub_device,
    .cc         = RDM_CC_GET_COMMAND,
    .pid        = RDM_PID_PARAMETER_DESCRIPTION,
    .pd         = &pid,
    .pdl        = sizeof(pid),
    .format     = "w$",   /* outgoing PD: the PID being queried */
  };

  const char *format = "wbbbx00bbddda";
  return rdm_send_request(dmx_num, &request, format, param_desc,
                          sizeof(*param_desc), ack);
}

/* ---------------------------------------------------------------------------
 * rdm_send_get_current_curve()
 * ------------------------------------------------------------------------- */
size_t rdm_send_get_current_curve(dmx_port_t dmx_num,
                                   const rdm_uid_t *dest_uid,
                                   rdm_sub_device_t sub_device,
                                   rdm_curve_id_t *curve,
                                   rdm_ack_t *ack) {
  if (dmx_num >= DMX_NUM_MAX)           return 0;
  if (dest_uid == NULL)                 return 0;
  if (rdm_uid_is_broadcast(dest_uid))   return 0;  /* GET requires unicast */
  if (sub_device >= RDM_SUB_DEVICE_MAX) return 0;
  if (curve == NULL)                    return 0;

  const rdm_request_t request = {
    .dest_uid  = dest_uid,
    .sub_device = sub_device,
    .cc        = RDM_CC_GET_COMMAND,
    .pid       = RDM_PID_MFR_CURVE,
    /* .pd / .pdl / .format zero-initialised — GET carries no outgoing PD */
  };

  /* "w$" — decode exactly one uint16_t from the response PD, then stop. */
  const char *format = "w$";
  return rdm_send_request(dmx_num, &request, format, curve,
                          sizeof(*curve), ack);
}

/* ---------------------------------------------------------------------------
 * rdm_send_set_current_curve()
 * ------------------------------------------------------------------------- */
bool rdm_send_set_current_curve(dmx_port_t dmx_num,
                                 const rdm_uid_t *dest_uid,
                                 rdm_sub_device_t sub_device,
                                 rdm_curve_id_t curve,
                                 rdm_ack_t *ack) {
  if (dmx_num >= DMX_NUM_MAX)  return false;
  if (dest_uid == NULL)        return false;
  /* SET may be broadcast (RDM_SUB_DEVICE_ALL) — mirror library behaviour */
  if (sub_device >= RDM_SUB_DEVICE_MAX &&
      sub_device != RDM_SUB_DEVICE_ALL) return false;

  const rdm_request_t request = {
    .dest_uid   = dest_uid,
    .sub_device = sub_device,
    .cc         = RDM_CC_SET_COMMAND,
    .pid        = RDM_PID_MFR_CURVE,
    .pd         = &curve,
    .pdl        = sizeof(curve),
    .format     = "w$",  /* outgoing PD: one uint16_t */
  };

  /* SET ACK carries no response PD — pass NULL output buffer. */
  size_t result = rdm_send_request(dmx_num, &request, NULL, NULL, 0, ack);

  /* Library returns 1 on ACK with zero PDL (see utils.c return path). */
  return (result > 0);
}
