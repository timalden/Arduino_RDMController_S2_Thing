/**
 * @file custom_controller.h
 * @brief RDM controller-side send functions for RDM_PID_MFR_CURVE.
 *
 * Modelled on the Weisbrod esp_dmx controller pattern (device_control.c/.h).
 * Place custom_controller.c and custom_controller.h in the sketch folder.
 *
 * RDM_PID_MFR_CURVE and rdm_curve_id_t are defined in custom.h — this file
 * includes it so the caller only needs one include.
 */
#pragma once

#include "custom.h"          /* RDM_PID_MFR_CURVE, rdm_curve_id_t           */
#include "rdm/controller.h"  /* rdm_ack_t, rdm_uid_t, rdm_sub_device_t      */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Sends an RDM GET RDM_PID_MFR_CURVE request and reads the response.
 *
 * Sent without parameter data. On ACK the response PD contains a single
 * uint16_t curve ID.
 *
 * @param dmx_num     DMX port number.
 * @param dest_uid    UID of the target responder (must not be broadcast).
 * @param sub_device  Sub-device number (use RDM_SUB_DEVICE_ROOT for root).
 * @param[out] curve  Receives the curve ID from the responder on success.
 * @param[out] ack    ACK metadata (response type, NACK reason, etc.).
 * @return            PDL bytes received (sizeof(rdm_curve_id_t) = 2 on ACK),
 *                    or 0 on timeout / error.
 */
size_t rdm_send_get_current_curve(dmx_port_t dmx_num,
                                   const rdm_uid_t *dest_uid,
                                   rdm_sub_device_t sub_device,
                                   rdm_curve_id_t *curve,
                                   rdm_ack_t *ack);

/**
 * @brief Sends an RDM SET RDM_PID_MFR_CURVE request and reads the response.
 *
 * Sent with a single uint16_t curve ID as parameter data. A successful ACK
 * carries no response PD.
 *
 * @param dmx_num    DMX port number.
 * @param dest_uid   UID of the target responder.
 * @param sub_device Sub-device number.
 * @param curve      Curve ID to set on the responder.
 * @param[out] ack   ACK metadata.
 * @return           true if RDM_RESPONSE_TYPE_ACK received, false otherwise.
 */
bool rdm_send_set_current_curve(dmx_port_t dmx_num,
                                 const rdm_uid_t *dest_uid,
                                 rdm_sub_device_t sub_device,
                                 rdm_curve_id_t curve,
                                 rdm_ack_t *ack);

#ifdef __cplusplus
}
#endif
